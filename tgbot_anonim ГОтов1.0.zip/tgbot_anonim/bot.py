import os
from dotenv import load_dotenv
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

# Загружаем переменные окружения из .env
load_dotenv()

# Загружаем значения переменных из .env
BOT_TOKEN = os.getenv('BOT_TOKEN')
GROUP_CHAT_ID = int(os.getenv('GROUP_CHAT_ID'))
ADMIN_IDS = os.getenv('ADMIN_IDS', '').split(',')  # Разделим строку по запятой

# Преобразуем значения в целые числа (если нужно работать с ID как числами)
ADMIN_IDS = [int(id) for id in ADMIN_IDS]

# Список сотрудников (по ID)
users = {}

# Логирование сообщений
def log_message(user_id, message):
    try:
        with open("logs/chat_log.txt", "a", encoding="utf-8") as log_file:
            log_file.write(f"User {user_id}: {message}\n")
    except Exception as e:
        print(f"Ошибка при записи в лог: {e}")

# Обработчик команды /start
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("Привет! Я бот, который обрабатывает команды и сообщения.")

# Обработчик команды /add_user
async def add_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Проверяем, что команду использует администратор
    if update.message.from_user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет прав для выполнения этой команды.")
        return

    if not context.args:
        await update.message.reply_text("⚠ Используйте: /add_user <user_id>")
        return

    user_id = int(context.args[0])
    # Добавляем пользователя в список
    if user_id not in users:
        users[user_id] = {"name": None}
        await update.message.reply_text(f"✅ Пользователь с ID {user_id} добавлен.")
    else:
        await update.message.reply_text(f"⚠ Пользователь с ID {user_id} уже существует.")

# Обработчик команды /set_name
async def set_name(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Проверяем, что команду использует администратор
    if update.message.from_user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет прав для выполнения этой команды.")
        return

    if not context.args:
        await update.message.reply_text("⚠ Используйте: /set_name <user_id> <name>")
        return

    user_id = int(context.args[0])
    name = " ".join(context.args[1:])

    if user_id in users:
        users[user_id]["name"] = name
        await update.message.reply_text(f"✅ Имя пользователя с ID {user_id} изменено на {name}.")
    else:
        await update.message.reply_text(f"⚠ Пользователь с ID {user_id} не найден.")

# Обработчик команд (например, /ban)
async def ban_user(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if update.message.from_user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ У вас нет прав для выполнения этой команды.")
        return

    if not context.args:
        await update.message.reply_text("⚠ Используйте: /ban <user_id>")
        return

    user_id = int(context.args[0])
    # Логика бана
    await update.message.reply_text(f"🔒 Пользователь {user_id} забанен.")

# Обработчик текстовых сообщений
async def handle_message(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # Проверяем, что сообщение отправлено пользователем, который есть в списке сотрудников
    user_id = update.message.from_user.id

    if user_id not in users:
        # Если пользователь не в списке сотрудников, удаляем его сообщение
        await update.message.delete()
        await update.message.reply_text("⛔ Вы не являетесь сотрудником, и не можете отправлять сообщения в чат.")
        return

    text = update.message.text

    # Логируем сообщение
    log_message(user_id, text)

    # Проверка на запрещенные слова
    BANNED_WORDS = ["оскорбление", "мат"]
    if any(word in text.lower() for word in BANNED_WORDS):
        await update.message.reply_text("Ваше сообщение содержит запрещенные слова и не будет отправлено.")
        return

    try:
        # Отправляем анонимное сообщение в групповой чат
        await context.bot.send_message(chat_id=GROUP_CHAT_ID, text=f"Аноним: {text}")
        await update.message.reply_text("Ваше сообщение отправлено в анонимный чат!")
    except Exception as e:
        print(f"Ошибка при отправке сообщения в групповой чат: {e}")
        await update.message.reply_text("Произошла ошибка при отправке сообщения. Попробуйте позже.")

# Главная функция
def main():
    try:
        # Создаем приложение
        application = ApplicationBuilder().token(BOT_TOKEN).build()

        # Регистрируем обработчики
        application.add_handler(CommandHandler("start", start))  # Обработчик команды /start
        application.add_handler(CommandHandler("add_user", add_user))  # Обработчик команды /add_user
        application.add_handler(CommandHandler("set_name", set_name))  # Обработчик команды /set_name
        application.add_handler(CommandHandler("ban", ban_user))  # Обработчик команды /ban
        application.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, handle_message))  # Обработчик для обычных сообщений

        print("Бот запущен...")
        application.run_polling()

    except Exception as e:
        print(f"Ошибка при запуске бота: {e}")

if __name__ == "__main__":
    main()
